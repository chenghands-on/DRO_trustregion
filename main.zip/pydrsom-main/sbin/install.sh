apt-get install python3
pip3 install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu113